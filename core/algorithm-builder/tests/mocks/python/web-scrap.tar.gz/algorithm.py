
import requests
_input = None


def init(args):
    print('algorithm: init')
    global _input
    _input = args["input"]

def start(args):
    print('algorithm: start')
    print('working...')

    url = _input[0]
    res = requests.get(url)
    
    return res.status_code


def stop(args):
    print('algorithm: stop')


def exit(args):
    print('algorithm: exit')
    code = args.get('exitCode', 0)
    print('Got exit command. Exiting with code', code)
    sys.exit(code)