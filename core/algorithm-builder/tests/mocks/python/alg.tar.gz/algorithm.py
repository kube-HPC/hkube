
import numpy as np
import test_package as tp
import base64

def start(args):
    print('algorithm: start')
    input = args["input"]
    x = input[0]
    y = input[1]
    nparray = tp.test(np.random.rand(x,y))
    jsonResult = [str(nparray.dtype), base64.b64encode(nparray), nparray.shape]
    return jsonResult
   
