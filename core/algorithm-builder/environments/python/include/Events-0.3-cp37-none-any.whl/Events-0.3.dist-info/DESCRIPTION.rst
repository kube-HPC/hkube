for more details.

Some rights reserved.

Redistribution and use in source and binary forms of the software as well
as documentation, with or without modification, are permitted provided
that the following conditions are met:

* Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

* Redistributions in binary form must reproduce the above
  copyright notice, this list of conditions and the following
  disclaimer in the documentation and/or other materials provided
  with the distribution.

* The names of the contributors may not be used to endorse or
  promote products derived from this software without specific
  prior written permission.

THIS SOFTWARE AND DOCUMENTATION IS PROVIDED BY THE COPYRIGHT HOLDERS AND
CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT
NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE AND DOCUMENTATION, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
DAMAGE.

Description: Events
        ~~~~~~
        .. image:: https://secure.travis-ci.org/pyeve/events.png?branch=master 
                :target: https://secure.travis-ci.org/pyeve/events
        
        The C# language provides a handy way to declare, subscribe to and fire events.
        Technically, an event is a "slot" where callback functions (event handlers) can
        be attached to - a process referred to as subscribing to an event. Here is
        a handy package that encapsulates the core to event subscription and event
        firing and feels like a "natural" part of the language.
        
        .. code-block:: pycon
         
            >>> def something_changed(reason): 
            ...     print "something changed because %s" % reason 
            ...
        
            >>> from events import Events
            >>> events = Events()
            >>> events.on_change += something_changed
        
        Multiple callback functions can subscribe to the same event. When the event is
        fired, all attached event handlers are invoked in sequence. To fire the event,
        perform a call on the slot: 
        
        .. code-block:: pycon
        
            >>> events.on_change('it had to happen')
            'something changed because it had to happen'
        
        By default, Events does not check if an event can be subscribed to and fired. 
        You can predefine events by subclassing Events and listing them. Attempts to
        subscribe to or fire an undefined event will raise an EventsException.
        
        .. code-block:: pycon
         
            >>> class MyEvents(Events):
            ...     __events__ = ('on_this', 'on_that', )
        
            >>> events = MyEvents()
        
            # this will raise an EventsException as `on_change` is unknown to MyEvents:
            >>> events.on_change += something_changed
        
        You can also predefine events for a single Events instance by passing an iterator to the constructor.
        
        .. code-block:: pycon
        
            >>> events = Events(('on_this', 'on_that'))
        
            # this will raise an EventsException as `on_change` is unknown to events:
            >>> events.on_change += something_changed
        
        
        Documentation
        -------------
        Complete documentation is available at http://events.readthedocs.org
        
        Installing
        ----------
        Events is on PyPI so all you need to do is: ::
        
            pip install events
        
        Testing
        -------
        Just run: ::
        
            python setup.py test
        
        Or use tox to test the package under all supported Pythons: 2.6, 2.7, 3.3, 3.4, 3.5 and 3.6. 
        
        License
        -------
        Events is BSD licensed. See the LICENSE_ for details.
        
        Contributing
        ------------
        Please see the `Contribution Guidelines`_.
        
        Attribution
        -----------
        Based on the excellent recipe by `Zoran Isailovski`_, Copyright (c) 2005.
        
        .. _LICENSE: https://github.com/pyeve/events/blob/master/LICENSE 
        .. _`Zoran Isailovski`: http://code.activestate.com/recipes/410686/
        .. _`Contribution Guidelines`: https://github.com/pyeve/events/blob/master/CONTRIBUTING.rst
        
Platform: any
Classifier: Development Status :: 4 - Beta
Classifier: Intended Audience :: Developers
Classifier: License :: OSI Approved :: BSD License
Classifier: Operating System :: OS Independent
Classifier: Programming Language :: Python
Classifier: Programming Language :: Python :: 2
Classifier: Programming Language :: Python :: 2.6
Classifier: Programming Language :: Python :: 2.7
Classifier: Programming Language :: Python :: 3
Classifier: Programming Language :: Python :: 3.3
Classifier: Programming Language :: Python :: 3.4
Classifier: Programming Language :: Python :: 3.5
Classifier: Topic :: Software Development
