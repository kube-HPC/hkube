echo Installing deps in script!!!
echo env is:
env
